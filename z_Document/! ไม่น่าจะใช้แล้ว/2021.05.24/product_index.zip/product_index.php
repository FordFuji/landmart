<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<?php require('inc_header.php'); ?>



</head>
<style>
.bottom_cart_more{
	position: absolute;
    bottom: -120px;
}

</style>
<body>
	<?php require('inc_topmenu.php'); ?>
	<div class="container-fluid mt-3">
		<div class="row">
			<div class="col">
				<div class="topbanner">
					<img src="images/product_banner.png" class="img-fluid" alt="">
				</div>


			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-8">
				<div class="title_product">
					<b> FARMING EQUIPMENT & SUPPLIES</b>
				</div>
			</div>
			<div class="col-md-4 text-md-right">



				<input type="checkbox" class="toggle" id="toggle" />

				<label for="toggle"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
						class="bi bi-info-circle" viewBox="0 0 16 16">
						<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
						<path
							d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
					</svg> เงื่อนไขการจัดส่งสินค้า</label>


				<div class="toggled text-md-left">
					<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
						Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero
						sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
				</div>




			</div>
		</div>
		<div class="row mb-3">
			<div class="col">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
						<li class="breadcrumb-item"><a href="#">เกษตร</a></li>
						<li class="breadcrumb-item active" aria-current="page">เครื่องยนต์และอุปกรณ์
						</li>
					</ol>
				</nav>
			</div>
		</div>
		<div class="row no-gutters">
			<div class="col-md-2 filter_left">
				<?php require('inc_sideproduct.php'); ?>
			</div>
			<div class="col-md-10 borderti ">
				<div class="boxbox_prod">
					<div class="borderti_bot">
						<div class="row ">
							<div class="col-md-6">
								<div class="mt-2">ค้นพบสินค้า 999 รายการสำหรับ "เกษตร"</div>
							</div>
							<div class="col-md-6 text-md-right">

								<div class="row">
									<div class="col">
										<div class="sortby">
											<select id="selectbasic" name="selectbasic" class="form-control arrow_down">
												<option value="" disabled selected>จัดเรียงตาม</option>
												<option value="1">Option one</option>
												<option value="2">Option two</option>
											</select>
										</div>
										<div class="showproduct">
											แสดง <div class="btn-group" role="group" aria-label="Basic example">
												<button type="button" class="btn btn-secondary">50</button>
												<button type="button" class="btn btn-secondary">100</button>

											</div>
											หน้า
										</div>
									</div>


								</div>

							</div>
						</div>
					</div>


					<br>
					<div class="row">
						<div class="col">

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>

										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>


										<div class="addselect">
											<a href="javascript:void(0);"
												class="btn btn-cart-select more-select">แสดงตัวเลือก</a>
										</div>
									</div>
								</div>

								<div class="product_cropbox" style="display:none;">
									<div class="more_chioce_box">
									
									<div class="display-slide" rel="1" style="display:block;">
									<div class="row">
										<div class="col-md-4 pad_right_no">
										<img src="images/newd/promotion7.png" class="img-fluid" alt="">
										</div>
										<div class="col-md-8 product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>
										</div>
									</div>
									
										</div>
										
										<div class="display-slide" rel="2">
										<div class="row">
										<div class="col-md-4 pad_right_no">
										<img src="images/newd/promotion8.png" class="img-fluid" alt="">
										</div>
										<div class="col-md-8 product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>
										</div>
									</div>
										</div>

										<div class="display-slide" rel="3">
										<div class="row">
										<div class="col-md-4 pad_right_no">
										<img src="images/newd/promotion8.png" class="img-fluid" alt="">
										</div>
										<div class="col-md-8 product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>
										</div>
									</div>
										</div>

										<span class="title_select">Select more</span>
										<div class="gallery_pic select-display-slide">
											<li class="active" rel="1">
												<a href="javascript:void(0)">
												Red
												</a>
											</li>
											<li rel="2">
												<a href="javascript:void(0)">
													Blue
												</a>
											</li>
											<li rel="3">
												<a href="javascript:void(0)">
													Black
												</a>
											</li>

										</div>
								
										
										<div class="bottom_cart_more">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>
									</div>

									<a href="javascript:void(0);" class="close-more-select">
									<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="#000" class="bi bi-x" viewBox="0 0 16 16">
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg>
									</a>
								</div>
							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>
							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="#">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>
							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="product_inside.php">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="#">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="#">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>

							<div class="each_product">
								<div class="product_cropbox">
									<div class="grad_product">
										<a href="#">
											<img src="images/newd/product_test.png" class="img-fluid" alt="">
										</a>
										<span class="savetag_new">
											SAVE
										</span>
										<div class="ribbon">
											32%
										</div>
									</div>

									<div class="product_box_details">
										<span class="brand_small">
											LANDMART
										</span>
										<h4>เครื่องสีข้าว 3 ระบบ 3in1 แลนด์มาร์ท</h4>
										<span class="wishlist_new">
											<a href="#"><img src="images/g2494_06.png"></a>
										</span>
										<span class="code_product">
											LM-6N150
										</span>
										<div class="price_original">
											฿ 13,500
										</div>
										<div class="price_discount">
											฿ 9,500
										</div>

										<div class="bottom_cart">
											<div class="qty_sm">
												<input type="text" class="form-control" value="1">
											</div>
											<div class="addcart">
												<a href="#" class="btn btn-cart-new"><svg
														xmlns="http://www.w3.org/2000/svg" width="18" height="18"
														fill="#000" class="bi bi-cart3" viewBox="0 0 16 16">
														<path
															d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
													</svg> สั่งซื้อสินค้า</a>
											</div>
										</div>

									</div>
								</div>

							</div>


						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
	<?php require('inc_footer.php'); ?>

	<script>
		$(document).ready(function () {



			$('.bannertop').owlCarousel({
				margin: 20,
				loop: true,
				item: 1,
				autoplay: false,
				autoplayTimeout: 4000,
				autoplayHoverPause: false,
				smartSpeed: 2000,
				dots: true,
				responsive: {
					0: {
						items: 1,
						slideBy: 1,
						margin: 10,
						nav: false,

					},
					600: {
						items: 1,
						slideBy: 1,
						nav: false,

					},
					1024: {
						items: 1,
						slideBy: 1
					},
					1200: {
						items: 1,
						slideBy: 1
					}
				}
			})

		});
	</script>
	<script type="text/javascript">
		$(document).ready(function () {
			$(".select-display-slide > li").click(function () {
				var rel = $(this).attr("rel");
				console.log(rel);
				$('.display-slide').hide();
				$('.display-slide[rel=' + rel + ']').fadeIn();
				$(".select-display-slide > li").removeClass("active");
				$(this).addClass("active");
			});
		});
	</script>
	
	<script>
								$(document).ready(function () {
									$(".more-select").click(function () {
										$(this).parents('.each_product').find('.product_cropbox').eq(0).hide();
										$(this).parents('.each_product').find('.product_cropbox').eq(1).show();
									});

									$('.close-more-select').click(function () {
										$(this).parents('.each_product').find('.product_cropbox').eq(0).show();
										$(this).parents('.each_product').find('.product_cropbox').eq(1).hide();
									});
								});
							</script>


</body>





</html>
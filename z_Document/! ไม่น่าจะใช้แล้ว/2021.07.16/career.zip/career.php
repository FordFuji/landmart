<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<?php require('inc_header.php'); ?>



</head>

<body>
	<?php require('inc_topmenu.php'); ?>
	<div class="container-fluid nopad">
		<div class="row">
			<div class="col">
				<div class="row">
					<div class="col-sm-12">
						<div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
							<!--	BANNER-PC			-->
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
							</div>
						</div>
						<!--	BANNER-MOBILE			-->
						<div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
							</div>
						</div>


					</div>
				</div>

			</div>
		</div>
	</div>
	<div class="content_wrap mt-5">
		<div class="row mb-3">
			<div class="col">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
						<li class="breadcrumb-item active" aria-current="page">ตำแหน่งงาน
						</li>
					</ol>
				</nav>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="search_filter_job">
					<div class="row">
						<div class="col">
							ค้นหางาน
							<div class="search_barbox">
								<input type="text" class="form-control" placeholder="Keyword">
							</div>
							<div class="search_barbox">
								<select id="selectbasic" name="selectbasic" class="form-control arrow_down">
									<option value="" disabled selected>All Job Function</option>
									<option value="1">Option one</option>
									<option value="2">Option two</option>
								</select>
							</div>
							<div class="search_barbox">
								<select id="selectbasic" name="selectbasic" class="form-control arrow_down">
									<option value="" disabled selected>All Location</option>
									<option value="1">Option one</option>
									<option value="2">Option two</option>
								</select>
							</div>
							<div class="search_barbox_btn">
								<a href="#" class="btn btn-yellow">Search</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row mt-3">
			<div class="col">
				<div class="position">
					Position - <span class="yellotxt bigtxt">All Positions</span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="box_position  gallery">
					<div class="left_number">01</div>
					<div class="center_job">
						<a href="career_detail.php" class="jobdetails">ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>  </a>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="career_detail.php" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">02</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">03</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">04</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">05</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">06</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>
				<div class="box_position  gallery">
					<div class="left_number">07</div>
					<div class="center_job">
						ผู้ช่วยช่างซ่อมทั่วไป <span class="urgent">ด่วน!</span> <span class="new">ใหม่</span>
						<div class="datepost"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar4-week" viewBox="0 0 16 16">
								<path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
								<path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
							</svg> 30 October 2020</div>
					</div>
					<div class="right_apply">
						<a href="#" class="btn btn-yellow">สมัคร</a>
					</div>
				</div>

			</div>
		</div>
		<div class="row mt-5 mb-5 wow">
			<div class="col">
				<center>
					<a class="loadMore btn btn-yellow-width" href="#">โหลดเพิ่มเติม</a>
				</center>
			</div>
		</div>

	</div>

	<?php require('inc_footer.php'); ?>

	<script>
		$(document).ready(function() {



			$('.bannertop').owlCarousel({
				margin: 20,
				loop: true,
				item: 1,
				autoplay: false,
				autoplayTimeout: 4000,
				autoplayHoverPause: false,
				smartSpeed: 2000,
				dots: true,
				responsive: {
					0: {
						items: 1,
						slideBy: 1,
						margin: 10,
						nav: false,

					},
					600: {
						items: 1,
						slideBy: 1,
						nav: false,

					},
					1024: {
						items: 1,
						slideBy: 1
					},
					1200: {
						items: 1,
						slideBy: 1
					}
				}
			})

		});

	</script>
	<script>
		$(function() {
			var numItems = $('.photo-container').length;
			console.log(numItems);
			$(".gallery").slice(0, 5).show();
			$(".loadMore").on('click', function(e) {
				e.preventDefault();
				$(".gallery:hidden").slice(0, 3).slideDown();
				if ($(".gallery:hidden").length == 0) {
					$(".load").fadeOut('slow');
				}
			});
		});

	</script>

</body>





</html>

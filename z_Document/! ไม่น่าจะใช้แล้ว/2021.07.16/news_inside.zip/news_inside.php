<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<?php require('inc_header.php'); ?>



</head>

<body>
	<?php require('inc_topmenu.php'); ?>
	<div class="container-fluid nopad">
		<div class="row">
			<div class="col">
				<div class="row">
					<div class="col-sm-12">
						<div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
							<!--	BANNER-PC			-->
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/news_banner.png" class="img-flag" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/news_banner.png" class="img-flag" alt=""></a>
								</div>
							</div>
						</div>
						<!--	BANNER-MOBILE			-->
						<div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/news_banner.png" class="img-flag" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/news_banner.png" class="img-flag" alt=""></a>
								</div>
							</div>
						</div>


					</div>
				</div>

			</div>
		</div>
		<div class="wrapper_pad">
		<div class="row mt-3">
			<div class="col">
				<div class="title_news_is">
			<h1>เปิดตัวใหม่สับหญ้าเร็วกว่าเดิมเพิมเติมคือของใหม่นี้แหละ</h1>	
				</div>
			</div>
		</div>
			<div class="row mt-3">
				<div class="col">
					<div class="title_img ">
						<img src="images/title_banner.png" class="img-fluid" alt="">
					</div>
				</div>
			</div>
			<div class="row mt-3">
				<div class="col">
					<div class="datenews">
						2 ธ.ค. 2563 08:30 น.
					</div>
				</div>
			</div>
		
		</div>
	</div>
	<?php require('inc_footer.php'); ?>

	<script>
		$(document).ready(function() {



			$('.bannertop').owlCarousel({
				margin: 20,
				loop: true,
				item: 1,
				autoplay: false,
				autoplayTimeout: 4000,
				autoplayHoverPause: false,
				smartSpeed: 2000,
				dots: true,
				responsive: {
					0: {
						items: 1,
						slideBy: 1,
						margin: 10,
						nav: false,

					},
					600: {
						items: 1,
						slideBy: 1,
						nav: false,

					},
					1024: {
						items: 1,
						slideBy: 1
					},
					1200: {
						items: 1,
						slideBy: 1
					}
				}
			})

		});

	</script>

</body>





</html>

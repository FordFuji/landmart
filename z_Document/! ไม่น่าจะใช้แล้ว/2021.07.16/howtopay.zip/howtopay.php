<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <?php require('inc_header.php'); ?>

</head>

<style>
    .left_howto {
        width: 5%;
        display: inline-block;
        vertical-align:bottom;
    }
    .right_howto{
        display:inline-block;
        width:70%;
        padding-top:30px;
    }

    .left_howto h1 {
        font-size: 5em;
    }
    .banner_top img{width:100%;}
    .boxwhite{
        padding:20px 50px;
    }
</style>

<body>
    <?php require('inc_topmenu.php'); ?>
    <div class="bgbodygray">
        <div class="container-fluid">
            <div class="col">
                <div class="wrapper_pad">
                    <div class="content_wrap">
                        <div class="row pt-3 mb-3">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"> การชำระเงิน
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="banner_top">
                                    <img src="images/howto/pay_icon_03.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="boxwhite">
                            <div class="row">
                                <div class="col">
                                    <div class="head_howto">
                                      
                                        <div class="right_howto">
                                            <h1>ช่องทางการชำระเงิน </h1>
                                            <p>มีคำถามเพิ่มเติมกรุณาโทรติดต่อ 09-2929-4998</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                        <img src="images/howto/pay_icon_07.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_09.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_11.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_13.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_15.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_17.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="howto_pic">
                                    <img src="images/howto/pay_icon_19.png" alt="" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc_footer.php'); ?>



</body>





</html>
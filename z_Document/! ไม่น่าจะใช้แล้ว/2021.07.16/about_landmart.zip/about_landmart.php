<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <?php require('inc_header.php'); ?>

</head>

<style>
    .left_howto {
        width: 5%;
        display: inline-block;
        vertical-align:bottom;
    }
    .right_howto{
        display:inline-block;
        width:70%;
        padding-top:30px;
    }

    .left_howto h1 {
        font-size: 5em;
    }
    .banner_top img{width:100%;}
</style>

<body>
    <?php require('inc_topmenu.php'); ?>
    <div class="bgbodygray">
        <div class="container-fluid">
            <div class="col">
                <div class="wrapper_pad">
                    <div class="content_wrap">
                        <div class="row pt-3 mb-3">
                            <div class="col">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"> เกี่ยวกับ Landmart
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                      
                        <div class="boxwhite">
                        <div class="row">
                            <div class="col">
                                <div class="banner_top">
                                    <img src="images/howto/about_pic_03.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                          <div class="content_text_abt mt-4">
                         <b>บริษัท แลนด์มาร์ท (ประเทศไทย) จำกัด</b>  ศูนย์รวมสินค้าวัสดุอุปกรณ์ทางการเกษตรและสินค้าเอ้าดอร์อย่างครบวงจรขนาดใหญ่และ
รูปแบบใหม่ จากเดิมที่เป็นธุรกิจสินค้าทางการเกษตรเพียงอย่างเดียว เราได้ขยายฐานกลุ่มเป้าหมายออกไปถึง เจ้าของฟาร์มทุกชนิด
ชาวนา-ชาวไร่-ชาวสวนไทยทุกคน ร้านค้าและโครงการต่างๆ กลุ่มแม่บ้านและร้านค้าชุมชน เจ้าของบ้านที่มีสวน จนไปถึงคนที่ชอบใช้ชีวิตภายนอก ในราคาที่ถูกที่สุดทุกวัน พร้อมกับสินค้าที่ครบครัน และคำแนะนำจากช่างผู้เชี่ยวชาญ ลูกค้าที่เข้ามาใช้บริการสามารถรับสินค้าได้ทันที หรือสามารถสั่งสินค้าทางเว็ปไซคและแพลทฟอร์มอื่นเพื่อจัดส่งถึงบ้านและฟาร์มได้อีกด้วย
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo1.png" class="img-fluid" alt=""></center> 
                         <h5><b>เกษตร</b></h5> 
เครื่องยนต์และวัสดุการเกษตรทุกชนิด เครื่องสีข้าว เครื่องนวดข้าว รถพรวนดิน รถไถเดินตาม เครื่องสับย่อย เครื่องพ่นยา ปั้มสวม
เครื่องหยอกเมล็ดพันธุ์ เครื่องสับหยวกกล้วย เครื่องกะเทาะเปลือกกาแฟ เครื่องยนต์เบนซินและดีเซล  ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo2.png" class="img-fluid" alt=""></center> 
                         <h5><b> ระบบน้ำ</b></h5> 
ปั้มน้ำอัตโนมัติ ปั้มหอยโข่ง ท่อพีวีซี ท่อพีอี ท่อพญานาค สปริงเกอร์ อุปกรณ์ชลประทานและการประปา ก๊อกน้ำ สายยาง สายส่งน้ำ ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo3.png" class="img-fluid" alt=""></center> 
                         <h5><b>  ครัวเรือน</b></h5> 

เตาแก๊ส เตาแม่บ้าน เตาย่าง ตราชั่ง ของใช้ในครัวเรือน ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo4.png" class="img-fluid" alt=""></center> 
                         <h5><b>    ฟาร์มเลี้ยงสัตว์</b></h5> 
ตาข่าย กรงไก่ ล้อมวัว อ๊อกซิเจนปลา อุปกรณ์การประมง ตาข่าย เชือก ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo5.png" class="img-fluid" alt=""></center> 
                         <h5><b>    ฟาร์มเลี้ยงสัตว์</b></h5> 
 
ตาข่าย กรงไก่ ล้อมวัว อ๊อกซิเจนปลา อุปกรณ์การประมง ตาข่าย เชือก ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo6.png" class="img-fluid" alt=""></center> 
                         <h5><b>     เครื่องมืออุตสาหกรรม</b></h5> 
  
เครื่องอัดเม็ด เครื่องขูดมะพร้าว เครื่องบดเนื้อ เครื่องทำขนมจีน เตาเครป เครื่องรีดถุง เครื่องทำขนม ฯลฯ
                          </div>
                          <div class="abt_group">
                             <center><img src="images/howto/abt_logo7.png" class="img-fluid" alt=""></center> 
                         <h5><b>กิจกรรมภายนอก</b></h5> 

ประเภทสินค้าใหม่ สนับสนุนกิจกรรมภายนอก
                          </div>
                          <div class="row">
                            <div class="col">
                                <div class="banner_top">
                                    <img src="images/howto/about_pic_btm.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require('inc_footer.php'); ?>



</body>





</html>
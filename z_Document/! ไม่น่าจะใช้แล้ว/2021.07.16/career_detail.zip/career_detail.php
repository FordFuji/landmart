<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<?php require('inc_header.php'); ?>



</head>

<body>
	<?php require('inc_topmenu.php'); ?>
	<div class="container-fluid nopad">
		<div class="row">
			<div class="col">
				<div class="row">
					<div class="col-sm-12">
						<div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
							<!--	BANNER-PC			-->
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
							</div>
						</div>
						<!--	BANNER-MOBILE			-->
						<div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
							<div class="bannertop owl-carousel owl-theme">
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
								<div class="item">
									<a href="#"><img src="images/career_banner.png" class="img-fluid" alt=""></a>
								</div>
							</div>
						</div>


					</div>
				</div>

			</div>
		</div>
	</div>
	<div class="content_wrap mt-5">
		<div class="row mb-3">
			<div class="col">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">หน้าหลัก</a></li>
						<li class="breadcrumb-item active" aria-current="page">ตำแหน่งงาน
						</li>
					</ol>
				</nav>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<div class="search_filter_job">
					<div class="row">
						<div class="col">
							ค้นหางาน
							<div class="search_barbox">
								<input type="text" class="form-control" placeholder="Keyword">
							</div>
							<div class="search_barbox">
								<select id="selectbasic" name="selectbasic" class="form-control arrow_down">
									<option value="" disabled selected>All Job Function</option>
									<option value="1">Option one</option>
									<option value="2">Option two</option>
								</select>
							</div>
							<div class="search_barbox">
								<select id="selectbasic" name="selectbasic" class="form-control arrow_down">
									<option value="" disabled selected>All Location</option>
									<option value="1">Option one</option>
									<option value="2">Option two</option>
								</select>
							</div>
							<div class="search_barbox_btn">
								<a href="#" class="btn btn-yellow">Search</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row mt-4">
			<div class="col">
				<h2 class="yellotxt">
					ผู้ช่วยช่างซ่อมทั่วไป</h2>
				<span class="yellotxt smtxt">เปิดรับสมัคร: 2 อัตรา</span>
			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-2">
				<b>รายละเอียดงาน</b>
			</div>
			<div class="col-md-10">
				1.บริหารการปลูกและบำรุงรักษาถั่วแระญี่ปุ่น การทำContract Farming เพื่อให้ได้ผลผลิตตามเป้าหมายที่กำหนดไว้ <br>
				2.สนับสนุนและส่งเสริมเทคนิคการปลูกถั่วแระญี่ปุ่นเพิ่มประสิทธิภาพในการเพาะปลูก <br>
				3.บริหารจัดการต้นทุนและงบประมาณการปลูกการส่งเสริม และการขยายพื้นที่ <br>
				4.บริหารจัดการการปฏิบัติงานของพนักงานทั้งหมดภายในไร่ <br>
				5.บริหารจัดการนำผลผลิตเข้าสู่กระบวนการให้ได้ตามเป้าหมายและคุณภาพภายในระยะเวลาที่กำหนด
			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-2">
				<b>คุณสมบัติผู้สมัคร
				</b>
			</div>
			<div class="col-md-10">
				1.เพศชาย อายุระหว่าง 35 - 40 ปี <br>
				2.การศึกษาระดับปริญญตรีขึ้นไป สาขาเกษตอุตสาหกรรม การบริหารจัดการไร่ หรือสาขาอื่นที่เกี่ยวข้อง <br>
				3.ประสบการณ์ 10 ปีขึ้นไป ในด้านการบริหารจัดการไร่ขนาดใหญ่ เช่น อ้อย ปาล์ม ข้าวโพด มันสำปะหลัง หรือสายงานเกษตรอื่น ๆ <br>
				4.มีความรู้เรื่องการเกษตรสมัยใหม่ <br>
				5.มีความรุ้เรื่องอุปกรณ์ เครื่องจักรทางการเกษตรเป็นอย่างดี <br>
				6.สามารถใช้งานโปรแกรม IoT ได้ <br>
				7.มีประสบการณ์ในการบริหารจัดการทีมงานตั้งแต่ 30 คนขึ้นไป <br>
				8.มีทักษะด้านการสื่อสารและการนำเสนอ <br>
				9.มีทักษะด้านการวิเคราะห์ปัญหา การคิดที่เป็นระบบ การสร้างทีมงาน และการบริหารงานบุคคล
			</div>
		</div>

		<div class="row mt-5 mb-5">
			<div class="col">
				<center>

					<a data-fancybox data-src="#detailjob" href="javascript:;" class="btn btn-yellow-width">
						สมัคร
					</a>
				</center>

				<div style="display: none;" id="detailjob">
					<h2>สนใจสมัครงาน</h2>
					<div class="formlist">
						<div class="row">
							<div class="col-md-6"><label>ชื่อ</label>
								<input type="text" class="form-control"></div>
							<div class="col-md-6">
								<label>นามสกุล</label>
								<input type="text" class="form-control">
							</div>
							<div class="col-md-6"><label>อีเมล</label>
								<input type="text" class="form-control"></div>
							<div class="col-md-6">
								<label>เบอร์ติดต่อ</label>
								<input type="text" class="form-control">
							</div>
						</div>
						
						<label>รายละเอียด</label>
						<textarea name="" id="" cols="30" rows="5" class="form-control"></textarea>
						<label class="mt-2">แนบไฟล์ Resume</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text">Upload</span>
							</div>
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="inputGroupFile01">
								<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
							</div>
						</div>
						<center><a href="#" class="btn btn-yellow-width">สมัครเลย</a></center>
					</div>
				</div>

			</div>
		</div>

	</div>

	<?php require('inc_footer.php'); ?>

	<script>
		$(document).ready(function() {



			$('.bannertop').owlCarousel({
				margin: 20,
				loop: true,
				item: 1,
				autoplay: false,
				autoplayTimeout: 4000,
				autoplayHoverPause: false,
				smartSpeed: 2000,
				dots: true,
				responsive: {
					0: {
						items: 1,
						slideBy: 1,
						margin: 10,
						nav: false,

					},
					600: {
						items: 1,
						slideBy: 1,
						nav: false,

					},
					1024: {
						items: 1,
						slideBy: 1
					},
					1200: {
						items: 1,
						slideBy: 1
					}
				}
			})

		});

	</script>

</body>





</html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Prompt:400,500,700|Roboto:400,500,700" rel="stylesheet">
</head>

<body>
    <style>
        body {
            font-family: 'Prompt', sans-serif;
            color: #000;
        }

        @media print {

            body,
            page {
                margin: 0;
                box-shadow: 0;
            }

            .breaknewpage {
                page-break-after: always;
            }
           
        }
    </style>

    <div class="page_container" style="padding: 15px 15px; max-width: 800px; width: 800px; min-width:800px; font-family:'Prompt', sans-serif;
    color: #000;">

<div class="bgYellowBlack" style="background:#f9c22a; height:15px;">
<div class="bgBlack" style="background:#000; width:100px; height:15px;"></div>
</div>

        <div class="logo" style="display:inline-block; width:50%;">
            <img src="images/mail_logo.png" alt="" style="width:400px;">
        </div>
        <div class="sellerText" style="display:inline-block; width:49%; color:#f9c22a;    font-size: 45px;
    text-transform: uppercase;
    vertical-align: top;
    margin-top: 20px;">
            Seller <span style="color:#6e6e70;">Center</span>
        </div>
        <div class="picklist_print" style="font-family: 'Roboto', 'Prompt', sans-serif;">
            Picklist printed : 12 Dec 2020
        </div>
         <div class="borderGray" style="border-bottom:4px solid #eee; padding-bottom:10px; width: 92.2%;">
         </div>
        

        <table class="table_order" style="    font-size: 15px;
    width: 740px;
    max-width: 740px;
    min-width: 740px;
    margin-top: 15px;
    border-collapse: collapse; ">
            <thead>
                <tr class="bg_gd" style="border:1px solid #dddee0;">

                    <th style="font-weight: 500; text-align: center; color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">SKU</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Image</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Product</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Order Number</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Quantity</th>

                </tr>

            </thead>

            <tbody style="border:1px solid #dddee0;">
               <tr>
                   <td style="border:1px solid #dddee0;">4123213123213</td>
                   <td style="border:1px solid #dddee0;">  <img class="logo" src="images/newd/promotion7.png"  style="margin: 0 auto 25px auto; width: 40%; height: auto; display: block;"></td>
              <td style="border:1px solid #dddee0;">รถพรวนดินแลนด์มาร์ท เครื่องยนต์เบนซิน 7 แรงม้า</td>
              <td style="border:1px solid #dddee0;">34234234324</td>
              <td style="border:1px solid #dddee0;">1</td>
                </tr>
            </tbody>

        </table>

<br>
        <div class="picklist_print" style="font-family: 'Roboto', 'Prompt', sans-serif;">
            Date: 11 Dec 2020 <br>
            Invoice-No.: INV - C234234234 <br>
            Order No.: 35434426 <br><br>
            Shipping Provider : Business Idea
        </div>
        <table class="table_order" style="    font-size: 15px;
    width: 740px;
    max-width: 740px;
    min-width: 740px;
    margin-top: 15px;
    border-collapse: collapse; ">
            <thead>
                <tr class="bg_gd" style="border:1px solid #dddee0;">

                    <th style="font-weight: 500; text-align: center; color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Order number</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Package tracking number</th>

                    <th style="    font-weight: 500;
text-align: center;
color: #231f20;
padding-bottom: 5px;
padding-top: 5px; ">Number of Pieces in Package</th>

                  

                </tr>

            </thead>

            <tbody style="border:1px solid #dddee0;">
               <tr>
                   <td style="border:1px solid #dddee0;">4123213123213</td>
                   <td style="border:1px solid #dddee0;">TH34324324</td>
                   <td style="border:1px solid #dddee0;">1</td>
                 
                </tr>
            </tbody>

        </table>

<br><br>

        <div class="boxOrder" style="border:1px solid #dddee0; width:350px; padding:5px 20px; margin-bottom:10px;">
            Total of Packages
        </div>
        <div class="boxOrder" style="border:1px solid #dddee0; width:350px; padding:5px 20px; margin-bottom:10px;">
           1
        </div>
        <div class="boxOrder" style="border:1px solid #dddee0; width:350px; padding:5px 20px;height:150px;">
            Date : Sat Dec 12 10:32:13 ICT 2020
        </div>
        <div class="boxOrder" style="border:1px solid #dddee0; width:350px; padding:5px 20px; margin-bottom:10px; height:130px;">
           Signature
        </div>

        <div class="borderGray" style="border-bottom:4px solid #eee; padding-bottom:10px; width: 92.2%;">
         </div>
<br><br>

         <div class="namesender" style="width:30%; display:inline-block;">
             <span class="blackBG" style="background:#000; border-radius:50px; padding:10px; color:#fff;">
                 ผู้จัดส่ง
             </span>
             <div class="addressMail" style="padding-top:20px;color:#595959;">
                 <div class="nameAddress" style="color:#000;"><b>LANDMART</b></div>
                 945 หมู่ 1 ต.เมืองพาน/Muangphan Sub-district <br> เชียงราย/Chiang Rai 
                 <br><br>
                 โทร 09-2929-4998
             </div>
         </div>
         <div class="senderIcon" style="width:10%; display:inline-block;">
             <img src="images/send_icon.png" alt="">
         </div>
         
         <div class="namesender" style="width:30%; display:inline-block;">
             <span class="blackBG" style="background:#000; border-radius:50px; padding:10px; color:#fff;">
                 ผู้รับสินค้า
             </span>
             <div class="addressMail" style="padding-top:20px;color:#595959;">
                 <div class="nameAddress" style="color:#000;"><b>นาย เกษตร น้ำประปา</b></div>
                 945 หมู่ 1 ต.เมืองพาน/Muangphan Sub-district <br> เชียงราย/Chiang Rai 
                 <br><br>
                 โทร 09-2929-4998
             </div>
         </div>
    </div>
   


 

    </div>

</body>
<style>
	.icon_footer {
		position: absolute;
		top: -45px;
	}

	.footergroup {
		position: relative;
	}

	.footerlink li {
		list-style: none;

	}

	.footercontent,
	.footerlink li a {
		color: gray;
	}

	.footerbg {
		background-color: #ffcd0a;
		padding: 5px;
		font-family: 'cloudsemibold';
	}

	.footerbg_black {
		background-color: #000;
		height: 54px;
	}

	.service_footer {
		text-align: center;
		padding: 10px 0px;
	}

	.service_footer li {
		display: inline-block;
		color: #a7a9ac;
		font-size: 1em;
		padding: 0px 30px;
	}

	.service_footer li img {
		vertical-align: middle;
	}

	.dev_group h4,
	.social_group h4,
	.footer_group h4 {
		font-size: 20px;
	}

	.dev_group li {
		list-style: none;
		display: inline-block;
		width: 17%;
	}

	.social_group li {
		list-style: none;
		display: inline-block;
	}

	.social_group li a img {
		width: 50px;
	}

	.deliverygroup li a img {
		width: 80px;
	}

	.deliverygroup li {
		list-style: none;
		display: inline-block;
	}

	.left_subscribe {
		float: left;
		width: 32%;
		padding-top: 8px;
		font-size: 1.1em;
		margin-right: 20px;
	}

	.right_subscribe {
		float: left;
		width: 62%;
	}

	.rightcrop {
		float: right;
		position: relative;
		width: 30%;
	}

	.dev_group li a img {
		width: 70%;
	}

	@media (max-width:1499px) {
		.rightcrop {
			width: 40%;
		}
	}
	@media (max-width: 991px) {
		.rightcrop {
			width: 100%;
		}

		.left_subscribe {
			width: 20%;
		}

		.right_subscribe {
			width: 60%;
		}
	}

	@media (max-width: 767px) {

		.rightcrop,
		.left_subscribe,
		.right_subscribe {
			width: 100%;
		}
	}

</style>

<div class="container-fluid nopad">
	<div class="footerbg">

		<div class="wrapper_pad">
			<div class="row">
				<div class="col">
					<div class="rightcrop">
						<div class="left_subscribe">รับโปรโมชั่นพิเศษสุดๆ</div>
						<div class="right_subscribe"><input type="text" class="form-control" placeholder="กรอกอีเมลตรงนี้"></div>


					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="footerbg_black"></div>

	<div class="wrapper_pad">
		<div class="whitefooter">
			<div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
				<div class="service_footer">
					<li><img src="images/newd/cs_1.png" alt=""> Customer Service 09-2929-4998</li>
					<li><img src="images/newd/cs_2.png" alt=""> ปลอดภัย</li>
					<li><img src="images/newd/cs_3.png" alt=""> ช้อปได้ทุกเวลา</li>
					<li><img src="images/newd/cs_4.png" alt=""> จัดส่งไว</li>
					<li><img src="images/newd/cs_5.png" alt=""> ปฎิบัติทางภาษีถูกต้อง</li>
				</div>
			</div>

			<div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
				<div class="menubottom_scroll">
					<li><img src="images/newd/cs_1.png" alt=""> Customer Service 09-2929-4998</li>
					<li><img src="images/newd/cs_2.png" alt=""> ปลอดภัย</li>
					<li><img src="images/newd/cs_3.png" alt=""> ช้อปได้ทุกเวลา</li>
					<li><img src="images/newd/cs_4.png" alt=""> จัดส่งไว</li>
					<li><img src="images/newd/cs_5.png" alt=""> ปฎิบัติทางภาษีถูกต้อง</li>
				</div>
			</div>

			<hr>

		</div>
		<hr><br>
		<div class="row mt-5 mb-3">
			<div class="col-md-3">
				<div class="footercontent">
					<h5><b style="color:#ffcc07;">LANDMART (THAILAND) CO., LTD. <br></b>
						<span style="color:#59595c;">บริษัท แลนด์มาร์ท (ประเทศไทย) จำำกัด </span> </h5>
					945 Village No.1, Mueang Phan Sub-district <br>
					Phan District, Chiang Rai Province, Thailand 57120

					<br><br>
					<h5><b style="color:#59595c;">
							ติดต่อเรา
						</b> </h5>
					TEL: <span style="color:#000;">09-2929-4998 </span><br>
					Line: <span style="color:#000;">landmart </span><br>
					อีเมล : <a href="mailto:contact@landmart.co.th" target="_blank" style="color:#000;">contact@landmart.co.th</a>
				</div>
			</div>
			<div class="col-md-6">
				<div class="row">
					<div class="col-md-4">
						<div class="footergroup">
							<span class="icon_footer">
								<img src="images/newd/cs_1.png" alt="">
							</span>
							<b style="color:#59595c;">ศูนย์บริการลูกค้า
							</b>
							<ul class="footerlink mt-2">
								<li><a href="#">แจ้งชำระเงิน</a></li>
								<li><a href="#">การสมัครสมาชิก</a></li>
								<li><a href="#">การสั่งซื้อสินค้า</a></li>
								<li><a href="#">การชำระเงิน</a></li>
								<li><a href="#">ขายสินค้ากับเรา (B2B)</a></li>
								<li><a href="#">เช็คสถานะการจัดส่ง</a></li>
								<li><a href="#">คำถามที่พบบ่อย</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="footergroup">

							<b style="color:#59595c;">Product Series </b><br>
							<ul class="footerlink mt-2">
								<li><a href="#">Smart Farm </a></li>
								<li><a href="#">Pump </a></li>
								<li><a href="#">Power Tools </a></li>
								<li><a href="#">Home & Garden </a></li>
								<li><a href="#">Industrial</a></li>
								<li><a href="#">Animal Farm </a></li>
								<li><a href="#">Outdoor </a></li>

							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="footergroup">
							<span class="icon_footer">
								<img src="images/newd/cs_2.png" alt="">
							</span>
							<b style="color:#59595c;">องค์กรเรา </b><br>
							<ul class="footerlink mt-2">
								<li><a href="#">เกี่ยวกับแลนด์มาร์ท</a></li>
								<li><a href="#">สมัครงาน</a></li>
								<li><a href="#">ข่าวสารและโปรโมชั่น</a></li>
							</ul>
						</div>
					</div>
				</div>


			</div>
			<div class="col-md-2">
				<b style="color:#59595c;">บริษัทขนส่งเอกชน </b><br>
				<ul class="footerlink mt-2">
					<li><a href="#">Flash</a></li>
					<li><a href="#">Business Idea</a></li>
					<li><a href="#">นิ่ม Express</a></li>
					<li><a href="#">นิ่มซี่เส็ง</a></li>
					<li><a href="#">SCG Express</a></li>
					<li><a href="#">Best Express</a></li>
					<li><a href="#">DHL</a></li>
					<li><a href="#">ไปรษณีย์ไทย</a></li>
					<li><a href="#">Blue & White Express</a></li>

				</ul>

			</div>
			<div class="col-md-1">
				<b style="color:#59595c;">ติดตามเรา</b><br>
				<ul class="footerlink mt-2">
					<li><a href="#"><img src="images/footer_icon_10.png" alt=""></a></li>
					<li><a href="#"><img src="images/footer_icon_13.png" alt=""></a></li>
					<li><a href="#"><img src="images/footer_icon_15.png" alt=""></a></li>
					<li><a href="#"><img src="images/footer_icon_17.png" alt=""></a></li>

				</ul>

			</div>
		</div>

		<div class="row">
			<div class="col">
				<img src="images/newd/newlogo.png" class="img-fluid" alt="">

			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col mb-3 mt-3">
				<div class="graytxt">Copyright © สงวนสิทธิ์ 2021 Landmart (Thailand) Co., Ltd. All rights reserved.</div>

			</div>
		</div>
	</div>
</div>

<style>
	.footerlink li {
		list-style: none;

	}

	.footercontent,
	.footerlink li a {
		color: gray;
	}

	.footerbg {
		background-color: #ffcd0a;
		padding: 5px;
		font-family: 'cloudsemibold';
	}

	.footerbg_black {
		background-color: #000;
		height: 54px;
	}

	.service_footer {
		text-align: center;
		padding: 10px 0px;
	}

	.service_footer li {
		display: inline-block;
		color: #a7a9ac;
		font-size: 1em;
		padding: 0px 30px;
	}

	.service_footer li img {
		vertical-align: middle;
	}

	.dev_group h4,
	.social_group h4,
	.footer_group h4 {
		font-size: 20px;
	}

	.dev_group li {
		list-style: none;
		display: inline-block;
		width: 17%;
	}

	.social_group li {
		list-style: none;
		display: inline-block;
	}

	.social_group li a img{
		width: 50px;
	}
	.deliverygroup li a img {
		width: 80px;
	}
	.deliverygroup li{
		list-style: none;
		display: inline-block;
	}

	.left_subscribe {
		float: left;
		width: 32%;
		padding-top: 8px;
		font-size: 1.1em;
		margin-right: 20px;
	}

	.right_subscribe {
		float: left;
		width: 62%;
	}

	.rightcrop {
		float: right;
		position: relative;
		width: 30%;
	}

	.dev_group li a img {
		width: 70%;
	}

	@media (max-width: 991px) {
		.rightcrop {
			width: 100%;
		}

		.left_subscribe {
			width: 20%;
		}

		.right_subscribe {
			width: 60%;
		}
	}

	@media (max-width: 767px) {

		.rightcrop,
		.left_subscribe,
		.right_subscribe {
			width: 100%;
		}
	}

</style>

<div class="container-fluid nopad">
	<div class="footerbg">

		<div class="wrapper_pad">
			<div class="row">
				<div class="col">
					<div class="rightcrop">
						<div class="left_subscribe">รับโปรโมชั่นพิเศษสุดๆ</div>
						<div class="right_subscribe"><input type="text" class="form-control" placeholder="กรอกอีเมลตรงนี้"></div>


					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="footerbg_black"></div>

	<div class="wrapper_pad">
		<div class="whitefooter">
			<div class="d-none d-sm-none d-md-none d-lg-block d-xl-block">
				<div class="service_footer">
					<li><img src="images/newd/cs_1.png" alt=""> Customer Service 09-2929-4998</li>
					<li><img src="images/newd/cs_2.png" alt=""> ปลอดภัย</li>
					<li><img src="images/newd/cs_3.png" alt=""> ช้อปได้ทุกเวลา</li>
					<li><img src="images/newd/cs_4.png" alt=""> จัดส่งไว</li>
					<li><img src="images/newd/cs_5.png" alt=""> ปฎิบัติทางภาษีถูกต้อง</li>
				</div>
			</div>

			<div class="d-block d-sm-block d-md-block d-lg-none d-xl-none">
				<div class="menubottom_scroll">
					<li><img src="images/newd/cs_1.png" alt=""> Customer Service 09-2929-4998</li>
					<li><img src="images/newd/cs_2.png" alt=""> ปลอดภัย</li>
					<li><img src="images/newd/cs_3.png" alt=""> ช้อปได้ทุกเวลา</li>
					<li><img src="images/newd/cs_4.png" alt=""> จัดส่งไว</li>
					<li><img src="images/newd/cs_5.png" alt=""> ปฎิบัติทางภาษีถูกต้อง</li>
				</div>
			</div>

			<hr>

		</div>
		<hr>
		<div class="row mt-3 mb-3">
			<div class="col-md-5">
			<div class="row">
				<div class="col-md-4">
					<img src="images/newd/newlogo.png" class="img-fluid" alt="">
				</div>
				<div class="col-md-8">
						<div class="footercontent">
					<b style="color:#000;">บริษัท แลนด์มาร์ท (ประเทศไทย) จำกัด </b><br>
					945 Village No.1, Mueang Phan Sub-district <br>
					Phan District, Chiang Rai Province, Thailand 57120

					<br><br>
					<b style="color:#000;">
						ติดต่อเรา
					</b> <br>
					เบอร์ติดต่อ : 099-262-8295, (053) 659-166 <br>
					อีเมล : <a href="mailto:contact@landmart.co.th" target="_blank">contact@landmart.co.th</a>
				</div>
				</div>
			</div>
			
			</div>
			<div class="col-md-2">
				<b>ศูนย์ดูแลลูกค้า </b><br>
				<ul class="footerlink">
					<li><a href="#">วิธีชำระเงินง่ายๆ</a></li>
					<li><a href="#">แจ้งชำระเงิน</a></li>
					<li><a href="#">เกี่ยวกับเรา</a></li>
					<li><a href="#">คู่ค้า</a></li>
				</ul>

			</div>
			<div class="col-md-2">
				<b>Follow us </b><br>
					<div class="social_group">
						<li><a href="#"><img src="images/newd/social_footer1.png" alt=""></a></li>
						<li><a href="#"><img src="images/newd/social_footer2.png" alt=""></a></li>
						<li><a href="#"><img src="images/newd/social_footer3.png" alt=""></a></li>
						<li><a href="#"><img src="images/newd/social_footer4.png" alt=""></a></li>
					</div>

			</div>
			<div class="col-md-3">
				<b>Delivery service</b><br>
						<ul class="deliverygroup">
						<li><a href="#"><img src="images/newd/logo_footer1.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer2.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer3.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer4.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer5.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer6.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer7.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer8.png" class="img-fluid" alt=""></a></li>
						<li><a href="#"><img src="images/newd/logo_footer9.png" class="img-fluid" alt=""></a></li>
				
				</ul>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col text-center mb-3 mt-3">
				@สงวนลิขสิทธิ์ 2564 เว็บไซต์ www.landmart.co.th

			</div>
		</div>
	</div>
</div>
